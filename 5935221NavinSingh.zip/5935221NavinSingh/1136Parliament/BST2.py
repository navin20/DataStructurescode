import sys
sys.setrecursionlimit(80000)
class Tree:
	def __init__(self):
		self.root = None
        
        
		

class Node: 
	def __init__(self, key): 
		self.key = key 
		self.left = None
		self.right = None
		self.parent= None
		
		



def inorder(root): 
	global e

	if root is not None: 
		e.append(root.key)
		inorder(root.left) 
		
		inorder(root.right) 
		
		

		
		
		
		


 
def insert(T, z):
	y = None
	x = T.root
	while x is not None:
		y = x
		if z.key < x.key:
			x = x.left
		else:
			x = x.right
	z.parent = y
	if y is None:
		T.root = z
	elif z.key < y.key:
		y.left = z
	else:
		y.right = z
	
	 




    

	




D = 3001
q = []

n = int(input())

for i in range(n):
	c = int(input())
	q.append(c)


t = Tree()
b = []
e = []
q.reverse()
for i in range(len(q)):
	q[i] = q[i]

for j in range(n):
	insert(t,Node(q[j]))



	








e = []  
l = []   



inorder(t.root)

e.reverse()
print(" ")
for i in range(n):
	print(str(e[i]),"")
		



















