from sys import stdout
import sys
sys.setrecursionlimit(70000)
def bubblesort(A):
    
    for i in range(len(A)-1):
        for j in range(len(A)-i-1):
            if A[j]<A[j+1]:
                temp = A[j]
                A[j] = A[j+1]
                A[j+1] = temp
    return A

class State():
    def __init__(self,weight,height):
        self.weight = weight
        self.height = height

def getting(x):
    return x.height
n = int(input())
f =[]
g = []
t =[]
for i in range(n):
    c = input().split()
    d = State(int(c[0]),int(c[1]))
    f.append(d)


f.sort(key = getting,reverse = True)
for i in range(n):
    print(f[i].weight,end = " ")
    print(f[i].height)










        



