readLine = input().split()
n = int(readLine[0])
m = int(readLine[1])
oop = []
j = []
k = []

for i in range(m):
    g = input().split()
    g[0] = int(g[0])
    j.append(g[0])
    g[1] = int(g[1])
    k.append(g[1])

s = list(map(int,input().split()))
# for  i in range(n):
#     oop[int(s[i])] = i+1


ui  = []
ui.append(j[0])
for i in range(m):
    if j[i]<=k[i]:
        ui.append(k[i])



# if c:
#     print("YES")
# else:
#     print("NO")

# s.reverse()
# ui.reverse()

if ui==s:
    print("YES")
else:
    print("NO")
